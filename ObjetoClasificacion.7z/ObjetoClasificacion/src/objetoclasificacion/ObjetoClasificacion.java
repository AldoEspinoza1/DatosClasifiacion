/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetoclasificacion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Aldo
 */
public class ObjetoClasificacion {

   public static void main(String[] args) {
		// TODO Auto-generated method stub
            String palabra = "Hola Mundo";
            float valor3 = (float) 3.1416;
            boolean verdadero = false;
            ArrayList<String> lista1 = new ArrayList<>();
            lista1.add("Hola");
            lista1.add("Mundo");
            lista1.add("Soy Aldo");
		
               
	System.out.print(palabra+"=");verificarObjeto(palabra);
	System.out.print(valor3+"=");verificarObjeto(valor3);
        System.out.print(lista1+"=");verificarObjeto(lista1);
	System.out.print(verdadero+"=");verificarObjeto(verdadero);
	
	}
	public static void verificarObjeto(Object objeto) {
		if(objeto.getClass() ==Float.class) {
			System.out.println("Un numero");
		}else if(objeto.getClass() == String.class){
			System.out.println("Una  una palabra");
		}else if(objeto.getClass() ==ArrayList.class){
			System.out.println("Una lista");
		}else {
			System.out.println("Otro tipo de dato");
		}
	}
}
